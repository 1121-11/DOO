package co.edu.uco.nose.initializer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiNoseApplicationTests {

	@Test
	void contextLoads() {
	}

}
