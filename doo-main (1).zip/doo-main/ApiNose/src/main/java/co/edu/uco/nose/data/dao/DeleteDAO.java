package co.edu.uco.nose.data.dao;

public interface DeleteDAO<ID> {
	void delete(ID id);
}
