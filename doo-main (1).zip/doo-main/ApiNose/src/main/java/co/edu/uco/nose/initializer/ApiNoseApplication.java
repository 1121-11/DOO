package co.edu.uco.nose.initializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiNoseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiNoseApplication.class, args);
	}

}
