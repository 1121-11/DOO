package co.edu.uco.nose.data.dao;

public interface CreateDAO<E> {
	void create(E entity);
}
