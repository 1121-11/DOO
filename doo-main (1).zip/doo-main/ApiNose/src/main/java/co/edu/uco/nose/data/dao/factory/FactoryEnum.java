package co.edu.uco.nose.data.dao.factory;

enum FactoryEnum {
	MYSQL,
	ORACLE,
	POSTGRESQL,
	SQLSERVER
}
