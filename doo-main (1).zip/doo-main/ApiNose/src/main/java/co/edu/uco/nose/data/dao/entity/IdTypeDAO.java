package co.edu.uco.nose.data.dao.entity;

import co.edu.uco.nose.entity.IdTypeEntity;

import java.util.UUID;

import co.edu.uco.nose.data.dao.RetrieveDAO;

public interface IdTypeDAO extends RetrieveDAO<IdTypeEntity, UUID> {

}
