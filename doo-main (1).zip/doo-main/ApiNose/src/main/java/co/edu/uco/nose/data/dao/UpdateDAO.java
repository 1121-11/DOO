package co.edu.uco.nose.data.dao;

public interface UpdateDAO<E> {
	void update(E entity);
}
