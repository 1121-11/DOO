package co.edu.uco.nose.data.dao.entity;

import java.util.UUID;

import co.edu.uco.nose.data.dao.RetrieveDAO;
import co.edu.uco.nose.entity.StateEntity;

public interface StateDAO extends RetrieveDAO<StateEntity, UUID> {

}
